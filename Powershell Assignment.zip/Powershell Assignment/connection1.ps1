

connect-VIserver 10.207.214.202 -user pratibha@imscoecloud.com -password cloud@123


