

Param(
            
                $myserverip = $( Read-Host "Input Ip, please" ),                
                $myusername = $( Read-Host "Input Username, please" ),
		$mypassname = $( Read-Host "Input password, please" )
                
     )

function CheckConnection{
		
	if(Connect-VIServer -Server $myserverip -user "$myusername" -password "$mypassname")
              {
		Write-Host "You are connected to host $ip successfully"
                countVm
	      }
	else{
		Write-Host "Your connection was not successful, please verify your username name and password"
	    }
}

function countVm{
$testArray = [System.Collections.ArrayList]@()
$tempArray = Get-Datastore

foreach($item in $tempArray)
{

    $arrayID = $testArray.Add($item)
      write-host($arrayID,$item)
}

   
$dataStore=read-host("Enter the Datastore name ")


$num = Get-Datastore $dataStore | Select @{N=�TotalVMs�;E={@($_ | Get-VM ).Count}}| Export-Csv -Path C:\Users\Administrator\Desktop\completed\assign10.csv
write-host($num)

}
CheckConnection