
function pool
{
Get-VMHost |Select name,
		@{n="ResourcePool"; e={$_ | Get-ResourcePool}},	
		@{N=�Cluster�;E={Get-Cluster -VMHost $_}},
		@{N=�NumVM�;E={($_ |Get-VM).Count}}, 
		@{N=�NumTemplates�;E={($_ |Get-Template).Count}} |Sort Cluster,Name
 
}
pool  
