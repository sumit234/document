

connect-VIserver 10.207.214.152 -user esxiuser -password cloud@123


