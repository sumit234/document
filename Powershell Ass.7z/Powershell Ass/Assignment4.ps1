#Add-PSSnapin VMware.VimAutomation.Core

Param(
            
                $myserverip = $( Read-Host "Input Ip, please" ),                
                $myusername = $( Read-Host "Input Username, please" ),
		$mypassname = $( Read-Host "Input password, please" )
                
     )

function CheckConnection{
		
	if(Connect-VIServer -Server $myserverip -user "$myusername" -password "$mypassname")
              {
		Write-Host "You are connected to host $ip successfully"
                PowerState
	      }
	else{
		Write-Host "Your connection was not successful, please verify your username name and password"
	    }
}
function PowerState{

Write-Host("VM with On state :") 
(Get-VM |Where {$_.PowerState -eq "PoweredOn"}).Count

Get-VM |Where {$_.PowerState -eq "PoweredOn"}| select Name

Write-Host("VM with Off state :") 
(Get-VM |Where {$_.PowerState -eq "PoweredOff"}).Count
Get-VM |Where {$_.PowerState -eq "PoweredOff"}| select Name

}
CheckConnection
