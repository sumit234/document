Get-VM | Select Name ,@{N="ESX Host";E={Get-VMHost -VM $_}}


#@{N="Datastore";E={Get-Datastore -VM $_}} 