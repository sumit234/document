Param(
            
                $myserverip = $( Read-Host "Input Ip, please" ),                
                $myusername = $( Read-Host "Input Username, please" ),
		$mypassname = $( Read-Host "Input password, please" )
                
     )

function CheckConnection{
		
	if(Connect-VIServer -Server $myserverip -user "$myusername" -password "$mypassname")
              {
		Write-Host "You are connected to host $ip successfully"
                countVm
	      }
	else{
		Write-Host "Your connection was not successful, please verify your username name and password"
	    }
}
function countVm{

             $tempArray = Get-Datastore
             foreach($item in $tempArray){

   
             $name = Get-Datastore $item | Select Name, @{N=�TotalVMs�;E={@($_ | Get-VM ).Count}}
             write-host("$name")
}
    
}CheckConnection
