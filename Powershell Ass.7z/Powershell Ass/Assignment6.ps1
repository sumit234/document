function getdetails{


$Day = $(Read-Host "Enter day of month")
if ($Day -eq '')
{$Day = Get-Date -format dd}

                   Get-VM | Where {$_.PowerState -eq "PoweredOn"} | 
                   Select Name, VMHost, NumCpu, MemoryMB, 
                   @{N="Cpu.UsageMhz.Average";E={[Math]::Round((($_ |Get-Stat -Stat cpu.usagemhz.average -Start ($Day).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}}, 
                   @{N="Mem.Usage.Average";E={[Math]::Round((($_ |Get-Stat -Stat mem.usage.average -Start ($Day).AddHours(-24)-IntervalMins 5 -MaxSamples (12) |Measure-Object Value -Average).Average),2)}} `
                   | Export-Csv C:\Users\Administrator\Desktop\completed\report.csv 
}
getdetails